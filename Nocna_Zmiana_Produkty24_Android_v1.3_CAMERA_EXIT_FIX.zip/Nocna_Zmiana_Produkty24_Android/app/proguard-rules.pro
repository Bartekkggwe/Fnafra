# Brak dodatkowych reguł ProGuard w wersji 1.0.
