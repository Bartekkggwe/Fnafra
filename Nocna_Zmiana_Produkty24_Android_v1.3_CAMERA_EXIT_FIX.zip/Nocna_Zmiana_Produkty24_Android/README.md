# Nocna Zmiana: Produkty 24

Mobilna gra horrorowa w klimacie post-sowieckiego osiedlowego sklepu 24h. Projekt Android działa całkowicie offline: gra znajduje się w `app/src/main/assets/index.html`, a natywna aplikacja uruchamia ją pełnoekranowo w WebView.

## Jak zbudować APK na GitHubie

1. Utwórz nowe repozytorium na GitHubie.
2. Wgraj **całą zawartość tego folderu** do repozytorium.
3. Wejdź w zakładkę **Actions**.
4. Otwórz workflow **Build Android APK**.
5. Jeżeli nie uruchomił się sam, kliknij **Run workflow**.
6. Po zakończeniu buildu otwórz ukończone zadanie.
7. Na dole w sekcji **Artifacts** pobierz `Nocna-Zmiana-Produkty24-APK`.
8. W ZIP-ie będzie `app-debug.apk`. Przenieś go na telefon i zainstaluj.

Android może poprosić o zgodę na instalowanie aplikacji z danego źródła. To normalne dla APK pobranego poza Google Play.

## Wymagania

- Android 8.0 lub nowszy (`minSdk 26`).
- Internet nie jest potrzebny do gry.
- GitHub Actions do zbudowania APK używa JDK 17, Gradle 8.9 i Android Gradle Plugin 8.7.3.

## Sterowanie

- **MONITOR** — otwiera monitoring.
- **ROLETA** — zamyka wejście, gdy przeciwnik dochodzi do drzwi.
- **ŚWIATŁO** — zbija poziom zakłóceń w sklepie kosztem energii.
- **CAM 01–04** — wybór kamery.
- Przetrwaj od 00:00 do 06:00.

Gra zawiera trzy noce o rosnącym poziomie trudności.
